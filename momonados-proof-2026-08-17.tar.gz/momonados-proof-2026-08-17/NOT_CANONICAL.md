# This directory is a snapshot, not the source

Built 2026-08-17T17:42:26Z from the tree at
/home/mrnob0dy666/imsgct/mOMonadOS.

It carries copies — imasm_core among them — that were current on the build date
and drift from the moment the source moves. Read it to RUN the kernel as it
stood. Do not read it to learn what the kernel does now, and never cite a path
inside it as canonical: cite the live tree.
